function Welcome() {
  return <h2>Welcome to React</h2>;
}

function App3() {
  return (
    <div>
      <Welcome />
    </div>
  );
}
export default App3