function App2() {
  const name = "Harsha";
  return (
    <div>
      <h1>Hello, {name}!</h1>
      <p>2 + 3 = {2 + 3}</p>
    </div>
  );
}
export default App2