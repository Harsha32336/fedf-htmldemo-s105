import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
//import NonStateObject from './NonStateObject'
//import PropsDemo from './PropsDemo'
//import App3 from './App3.jsx'
import StateObjectDemo from './StateObjectDemo'
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <StateObjectDemo/>
  </StrictMode>,
)
